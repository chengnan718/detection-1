from imread_from_url.imread_from_url import *

__version__ = "0.1.0"